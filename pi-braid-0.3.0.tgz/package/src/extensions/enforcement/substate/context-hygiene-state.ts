/**
 * Context Hygiene & Scratchpad - state interface and helpers for context usage
 * tracking and scratchpad nudge timing. Merged because both track nudge timing
 * and recordCompaction() already cross-references lastScratchpadNudgeTurn.
 * Does NOT import state.ts (breaks circular dependency).
 */

// ── Scratchpad sub-state ──────────────────────────────────────────────────

export interface ScratchpadState {
  lastScratchpadNudgeTurn: number;
  claimsDetectedThisTurn: boolean;
  claimsWithoutVerification: number;
  verificationsDone: number;
  // Per-turn think-before-edit nudge cooldown
  lastThinkPerTurnNudge: number;
  // Startup nudge: first 3 turns without scratchpad goal
  lastStartupNudge: number;
  // Whether the startup-plan whisper was sent (drives PLANNING mode)
  startupPlanShown: boolean;
  // Tools called since last scratchpad goal was set (drives PLANNING mode at any turn)
  toolsSinceLastPlan: number;
  // Finalize enforcement nudge
  lastFinalizeNudge: number;
  // Verify enforcement nudge
  lastVerifyNudge: number;
  // Phase-aware enforcement: tracks investigation→implementation transitions
  lastInvestigationToolTurn: number;
  lastPhaseNudgeTurn: number;
  consecutiveInvestigationTurns: number;
  // Task complexity from initial request classifier (set on SESSION_START)
  taskComplexity: "simple" | "moderate" | "complex" | "unknown";
}

export function createScratchpadState(): ScratchpadState {
  return {
    lastScratchpadNudgeTurn: -100,
    claimsDetectedThisTurn: false,
    claimsWithoutVerification: 0,
    verificationsDone: 0,
    lastThinkPerTurnNudge: -100,
    lastStartupNudge: -100,
    startupPlanShown: false,
    toolsSinceLastPlan: 0,
    lastFinalizeNudge: -100,
    lastVerifyNudge: -100,
    lastInvestigationToolTurn: -100,
    lastPhaseNudgeTurn: -100,
    consecutiveInvestigationTurns: 0,
    taskComplexity: "unknown",
  };
}

export function resetScratchpadState(s: ScratchpadState): void {
  s.lastScratchpadNudgeTurn = -100;
  s.claimsDetectedThisTurn = false;
  s.claimsWithoutVerification = 0;
  s.verificationsDone = 0;
  s.lastThinkPerTurnNudge = -100;
  s.lastStartupNudge = -100;
  s.startupPlanShown = false;
  s.toolsSinceLastPlan = 0;
  s.lastFinalizeNudge = -100;
  s.lastVerifyNudge = -100;
  s.lastInvestigationToolTurn = -100;
  s.lastPhaseNudgeTurn = -100;
  s.consecutiveInvestigationTurns = 0;
  s.taskComplexity = "unknown";
}

// ── Context Hygiene sub-state ──────────────────────────────────────────────

export interface ContextHygieneState {
  contextNudgeSent: boolean;
  lastContextCheckTurn: number;
  lastCompactionTurn: number;
  overflowRecently: number;
  contextCheckInterval: number;
  contextAuditThreshold: number;
  /**
   * Flag set by the context_compress tool before triggering compaction.
   * The session_compact handler checks this flag to determine whether to
   * auto-resume the agent (triggerTurn: true) after compaction.
   * - If true (set by tool): auto-resume (agent-initiated compaction)
   * - If false (unset): reason: "manual" means user typed /compress → skip
   *   reason: "threshold"|"overflow" means auto-compaction → auto-resume anyway
   */
  autoResumeAfterCompaction: boolean;
  /** Turn of the last post-cycle hygiene (auto-tag + inspect). Initialized to -100. */
  lastPostCycleHygieneTurn: number;
}

export function createContextHygieneState(): ContextHygieneState {
  return {
    contextNudgeSent: false,
    lastContextCheckTurn: 0,
    lastCompactionTurn: 0,
    overflowRecently: 0,
    contextCheckInterval: 15,
    contextAuditThreshold: 0.66,
    autoResumeAfterCompaction: false,
    lastPostCycleHygieneTurn: -100,
  };
}

export function resetContextHygieneState(s: ContextHygieneState): void {
  s.contextNudgeSent = false;
  s.lastContextCheckTurn = 0;
  s.lastCompactionTurn = 0;
  s.overflowRecently = 0;
  s.autoResumeAfterCompaction = false;
  s.contextCheckInterval = 15;
  s.contextAuditThreshold = 0.66;
  s.lastPostCycleHygieneTurn = -100;
}

// ── Helpers ────────────────────────────────────────────────────────────

import {
  USAGE_WHISPER_SOFT,
  USAGE_WHISPER_ADVISORY,
  USAGE_WHISPER_WARNING,
  USAGE_WHISPER_CRITICAL,
  USAGE_COMPACT_MEDIUM,
  USAGE_TOKENS_SOFT,
  USAGE_TOKENS_WARNING,
} from "../../../lib/detection/context-thresholds.js";

/** Mark context nudge as sent (system sends nudge to agent). */
export function markNudgeSent(s: ContextHygieneState, turn: number): void {
  s.contextNudgeSent = true;
  s.lastContextCheckTurn = turn;
}

/** Reset context nudge (e.g., after compaction freed space). */
export function resetNudge(s: ContextHygieneState): void {
  s.contextNudgeSent = false;
}

/** Record that a context management tool was used. */
export function recordContextTool(s: ContextHygieneState, turn: number): void {
  s.lastContextCheckTurn = turn;
  s.contextNudgeSent = false;
}

/** Record that compaction happened. Also resets scratchpad nudge timer. */
export function recordCompaction(
  s: ContextHygieneState & { lastScratchpadNudgeTurn?: number },
  turn: number,
): void {
  s.lastCompactionTurn = turn;
  s.lastContextCheckTurn = turn;
  s.contextNudgeSent = false;
  s.overflowRecently = turn;
  if (typeof s.lastScratchpadNudgeTurn === "number") {
    s.lastScratchpadNudgeTurn = turn;
  }
}

/** Record overflow detection. */
export function recordOverflow(s: ContextHygieneState, turn: number): void {
  s.overflowRecently = turn;
}

/** Returns true if still in overflow recovery grace period. */
export function inOverflowRecovery(
  s: ContextHygieneState,
  currentTurn: number,
  graceTurns = 5,
): boolean {
  return currentTurn - s.overflowRecently < graceTurns;
}

/** Should we check context usage this turn? */
export function shouldCheckContext(s: ContextHygieneState, turn: number): boolean {
  return turn - s.lastContextCheckTurn >= s.contextCheckInterval && !s.contextNudgeSent;
}

/** Return the severity-based message for current context usage. */
export function getContextNudgeMessage(usagePercent: number, usageTokens: number): string | null {
  if (usageTokens >= USAGE_TOKENS_WARNING) {
    return (
      `Context at ${Math.round(usageTokens / 1000)}K tokens (${Math.round(usagePercent)}%). ` +
      `Pipeline: context_navigate(action="tag") -> context_compress(action="archive") -> compact (last resort).`
    );
  }
  if (usageTokens >= USAGE_TOKENS_SOFT) {
    return (
      `Context at ${Math.round(usageTokens / 1000)}K tokens. ` +
      `Consider context_inspect(detail="prune") to see candidates, or tag position with context_navigate(action="tag").`
    );
  }
  // ── Progressive percentage-based messages ─────────────────────────
  if (usagePercent >= USAGE_COMPACT_MEDIUM) {
    return (
      `Context at ${Math.round(usagePercent)}%. Pipeline: context_navigate(action="tag") -> ` +
      `context_compress(action="archive") -> compact (last resort). Tag your position first.`
    );
  }
  if (usagePercent >= USAGE_WHISPER_CRITICAL) {
    return (
      `Context at ${Math.round(usagePercent)}%. Tag with context_navigate(action="tag"), then ` +
      `context_compress(action="archive") to branch with a summary.`
    );
  }
  if (usagePercent >= USAGE_WHISPER_WARNING) {
    return (
      `Context at ${Math.round(usagePercent)}%. Warning — tag with context_navigate(action="tag"), ` +
      `then context_compress(action="archive") to branch with a summary.`
    );
  }
  if (usagePercent >= USAGE_WHISPER_ADVISORY) {
    return (
      `Context at ${Math.round(usagePercent)}%. Advisory — consider context_archive for completed tasks. ` +
      `context_navigate(action="tag") to mark your position first.`
    );
  }
  if (usagePercent >= USAGE_WHISPER_SOFT) {
    return (
      `Context at ${Math.round(usagePercent)}%. Soft whisper — consider context_inspect(detail="prune") ` +
      `to see candidates for archival.`
    );
  }
  return null;
}

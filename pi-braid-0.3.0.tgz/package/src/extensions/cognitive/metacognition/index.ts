/**
 * Metacognition Extension - structured thinking, hypothesis generation, and task finalization.
 *
 * Decomposed into: think, hypothesize, finalize (each in handlers/).
 * All tools use the session model (ctx.model) directly - no separate utility model.
 * Research: docs/research/bicameral-mind-analysis.md
 */

import type { ExtensionAPI, ExtensionContext } from "@earendil-works/pi-coding-agent";
import { getExtensionState } from "../../../lib/state/extension-state.js";
import { createThinkTool, recordCalibration } from "./handlers/think.js";
import { createHypothesizeTool } from "./handlers/hypothesize.js";
import { createFinalizeTool } from "./handlers/finalize.js";
import { createVerifyTool } from "./handlers/verify.js";
import { registerClaimVerificationTools } from "./handlers/claim-verification.js";
import { TOOL_EXECUTION_END } from "../../../lib/core/event-names.js";

interface MetaMetrics {
  thinks: number;
  hypothesizes: number;
  finalizes: number;
  totalConfidence: number;
  hypothesesGenerated: number;
  hypothesesWithVerification: number;
  finalizationsBlocked: number;
  verifies: number;
  verificationsPassed: number;
  depthDistribution: Record<string, number>;
  reasoningTags: Record<string, number>;
}

function getMetaState(ctx: ExtensionContext): MetaMetrics {
  return getExtensionState<MetaMetrics>(ctx, "metacognition-metrics", () => ({
    thinks: 0,
    hypothesizes: 0,
    finalizes: 0,
    totalConfidence: 0,
    hypothesesGenerated: 0,
    hypothesesWithVerification: 0,
    finalizationsBlocked: 0,
    verifies: 0,
    verificationsPassed: 0,
    depthDistribution: {},
    reasoningTags: {},
  }));
}

export default function metacognitionExtension(pi: ExtensionAPI) {
  // Register tools. Each factory returns a properly typed
  // ToolDefinition<any, any, any> now (ROADMAP P2-1: typed-adapter
  // pattern) so the call site needs no `as` cast.
  pi.registerTool(createThinkTool());
  pi.registerTool(createHypothesizeTool());
  pi.registerTool(
    createFinalizeTool({
      onFinalize: (_summary, _completed) => {
        // Logging handled by the finalize tool's own execution
      },
      recordCalibration,
    }),
  );

  // ── Verify Tool ───────────────────────────────────────────────────────────
  pi.registerTool(createVerifyTool());

  // ── Claim Verification Tools (moved from cognitive/verification/) ──────────
  registerClaimVerificationTools(pi);

  // Track tool usage
  pi.on(TOOL_EXECUTION_END, (event: any, ctx: ExtensionContext) => {
    const toolName = event?.toolName ?? "";
    if (!ctx || !toolName) return;
    const state = getMetaState(ctx);

    if (toolName === "think") {
      state.thinks++;
      const depth = event?.params?.depth ?? "quick";
      state.depthDistribution[depth] = (state.depthDistribution[depth] ?? 0) + 1;
      const tags: string[] = event?.params?.tags ?? [];
      for (const tag of tags) {
        state.reasoningTags[tag] = (state.reasoningTags[tag] ?? 0) + 1;
      }
      if (event?.params?.confidence !== undefined) {
        state.totalConfidence += event.params.confidence;
      }
    } else if (toolName === "hypothesize") {
      state.hypothesizes++;
      state.hypothesesGenerated += event?.params?.maxHypotheses ?? 3;
      if (event?.details?.scores?.some((s: any) => s.signals?.includes("verification-plan"))) {
        state.hypothesesWithVerification++;
      }
    } else if (toolName === "finalize") {
      state.finalizes++;
      if (event?.details?.blocked) {
        state.finalizationsBlocked++;
      }
    } else if (toolName === "verify") {
      state.verifies++;
      if (event?.details?.passed) {
        state.verificationsPassed++;
      }
    }
  });

  // Tools removed (2026-04-28): cognition_evaluate / heuristics_evaluate.
  // Reason: rarely used, indirect metric. Heuristic definitions kept for enforcement use.
}
